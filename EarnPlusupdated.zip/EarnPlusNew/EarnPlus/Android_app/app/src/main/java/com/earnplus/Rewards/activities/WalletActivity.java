package com.earnplus.rewards.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.earnplus.rewards.R;
import com.earnplus.rewards.databinding.ActivityWalletBinding;
import com.earnplus.rewards.models.User;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WalletActivity extends AppCompatActivity {

    private ActivityWalletBinding binding;
    private DatabaseReference userRef, appConfigRef;
    private FirebaseAuth mAuth;
    private User currentUserData;
    private long minWithdrawCoins = 500; // Default value

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWalletBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setTitle("My Wallet & Withdraw");

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        if (firebaseUser == null) {
            // This should not happen if security is right, but as a fallback
            Toast.makeText(this, "You are not logged in.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        userRef = FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getUid());
        appConfigRef = FirebaseDatabase.getInstance().getReference("app_config").child("rewards");

        loadWalletData();
        binding.withdrawButton.setOnClickListener(v -> attemptWithdrawal());
    }

    private void loadWalletData() {
        // Fetch minimum withdrawal amount from Firebase
        appConfigRef.child("min_withdraw_coins").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    minWithdrawCoins = snapshot.getValue(Long.class);
                }
                binding.withdrawInfoText.setText("Minimum withdrawal is " + minWithdrawCoins + " coins.");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });

        // Listen for user's coin balance changes
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    currentUserData = snapshot.getValue(User.class);
                    if (currentUserData != null) {
                        binding.coinBalanceText.setText(String.valueOf(currentUserData.coins));
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(WalletActivity.this, "Could not load wallet details.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void attemptWithdrawal() {
        String paymentDetails = binding.paymentDetailsInput.getText().toString().trim();
        String amountString = binding.amountInput.getText().toString().trim();

        if (TextUtils.isEmpty(amountString)) {
            binding.amountInput.setError("Amount is required");
            return;
        }
        if (TextUtils.isEmpty(paymentDetails)) {
            binding.paymentDetailsInput.setError("Payment details are required");
            return;
        }

        long amountToWithdraw = Long.parseLong(amountString);

        if (currentUserData == null) {
            Toast.makeText(this, "User data not loaded yet. Please wait.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amountToWithdraw < minWithdrawCoins) {
            Toast.makeText(this, "Minimum withdrawal amount is " + minWithdrawCoins + " coins.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amountToWithdraw > currentUserData.coins) {
            Toast.makeText(this, "You do not have enough coins.", Toast.LENGTH_SHORT).show();
            return;
        }

        // All checks passed, proceed to submit request and deduct coins
        submitWithdrawalRequest(amountToWithdraw, paymentDetails);
    }
    
    private void submitWithdrawalRequest(long amount, String details) {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.withdrawButton.setEnabled(false);

        // Deduct coins first from Firebase
        long newCoinTotal = currentUserData.coins - amount;
        userRef.child("coins").setValue(newCoinTotal).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Coins deducted, now send request to PHP server
                sendRequestToServer(amount, details);
            } else {
                // Failed to deduct coins, do not proceed.
                Toast.makeText(WalletActivity.this, "Error updating balance. Please try again.", Toast.LENGTH_SHORT).show();
                binding.progressBar.setVisibility(View.GONE);
                binding.withdrawButton.setEnabled(true);
            }
        });
    }

    private void sendRequestToServer(long amount, String details) {
        OkHttpClient client = new OkHttpClient();
        String url = getString(R.string.admin_panel_api_url) + "create_withdrawal.php";

        RequestBody formBody = new FormBody.Builder()
                .add("uid", currentUserData.uid)
                .add("email", currentUserData.email)
                .add("amount", String.valueOf(amount))
                .add("method", "UPI/Paytm") // Or get from a RadioGroup
                .add("details", details)
                .build();

        Request request = new Request.Builder().url(url).post(formBody).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> {
                    // Critical: Add coins back if server request fails
                    userRef.child("coins").setValue(currentUserData.coins);
                    Toast.makeText(WalletActivity.this, "Network Error. Coins have been refunded.", Toast.LENGTH_LONG).show();
                    binding.progressBar.setVisibility(View.GONE);
                    binding.withdrawButton.setEnabled(true);
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String responseBody = response.body().string();
                runOnUiThread(() -> {
                    try {
                        JSONObject json = new JSONObject(responseBody);
                        if (json.getString("status").equals("success")) {
                            Toast.makeText(WalletActivity.this, "Withdrawal request submitted successfully!", Toast.LENGTH_LONG).show();
                            // Clear inputs
                            binding.amountInput.setText("");
                            binding.paymentDetailsInput.setText("");
                        } else {
                            // Add coins back if server reports an error
                            userRef.child("coins").setValue(currentUserData.coins);
                            Toast.makeText(WalletActivity.this, "Server Error: " + json.getString("message") + ". Coins refunded.", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // Add coins back for malformed response
                        userRef.child("coins").setValue(currentUserData.coins);
                        Toast.makeText(WalletActivity.this, "An unexpected error occurred. Coins refunded.", Toast.LENGTH_LONG).show();
                    } finally {
                        binding.progressBar.setVisibility(View.GONE);
                        binding.withdrawButton.setEnabled(true);
                    }
                });
            }
        });
    }
}