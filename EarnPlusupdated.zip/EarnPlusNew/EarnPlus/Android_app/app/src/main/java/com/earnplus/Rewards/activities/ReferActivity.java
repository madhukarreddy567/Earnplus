package com.earnplus.rewards.activities;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.earnplus.rewards.databinding.ActivityReferBinding;
import com.earnplus.rewards.models.User;

public class ReferActivity extends AppCompatActivity {

    private ActivityReferBinding binding;
    private DatabaseReference userRef;
    private String userReferralCode = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityReferBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setTitle("Refer & Earn");

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "You need to be logged in to refer.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        userRef = FirebaseDatabase.getInstance().getReference("users").child(currentUser.getUid());
        loadReferralCode();

        binding.copyCodeButton.setOnClickListener(v -> copyCodeToClipboard());
        binding.shareNowButton.setOnClickListener(v -> shareReferralLink());
    }

    private void loadReferralCode() {
        binding.progressBar.setVisibility(View.VISIBLE);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                binding.progressBar.setVisibility(View.GONE);
                if (snapshot.exists()) {
                    User user = snapshot.getValue(User.class);
                    if (user != null && user.referralCode != null) {
                        userReferralCode = user.referralCode;
                        binding.referralCodeText.setText(userReferralCode);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                binding.progressBar.setVisibility(View.GONE);
                Toast.makeText(ReferActivity.this, "Failed to load referral code.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void copyCodeToClipboard() {
        if (userReferralCode.isEmpty()) {
            Toast.makeText(this, "Referral code not loaded yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("ReferralCode", userReferralCode);
        clipboard.setPrimaryClip(clip);

        Toast.makeText(this, "Code copied to clipboard!", Toast.LENGTH_SHORT).show();
    }

    private void shareReferralLink() {
        if (userReferralCode.isEmpty()) {
            Toast.makeText(this, "Referral code not loaded yet.", Toast.LENGTH_SHORT).show();
            return;
        }

        // IMPORTANT: Replace with your actual app's link on the Google Play Store
        String playStoreLink = "https://play.google.com/store/apps/details?id=" + getPackageName();

        String shareMessage = "Hey! I'm using EarnPlus to earn real rewards. Sign up with my code '"
                + userReferralCode
                + "' and we both get a bonus! 🎁\n\nDownload the app now:\n"
                + playStoreLink;

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        startActivity(Intent.createChooser(shareIntent, "Share your referral code via..."));
    }
}