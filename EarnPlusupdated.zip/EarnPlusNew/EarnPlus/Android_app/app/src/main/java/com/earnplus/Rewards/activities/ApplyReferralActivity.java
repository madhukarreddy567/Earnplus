package com.earnplus.rewards.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Query;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;
import com.earnplus.rewards.databinding.ActivityApplyReferralBinding;
import com.earnplus.rewards.models.User;

public class ApplyReferralActivity extends AppCompatActivity {

    private ActivityApplyReferralBinding binding;
    private DatabaseReference mDatabase;
    private String currentUserId;
    private long referralBonus = 100; // Default bonus, should be fetched from app_config

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityApplyReferralBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setTitle("Claim Your Bonus");

        mDatabase = FirebaseDatabase.getInstance().getReference();
        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        binding.submitButton.setOnClickListener(v -> applyReferralCode());
        binding.skipButton.setOnClickListener(v -> goToMain());
    }

    private void applyReferralCode() {
        String code = binding.referralCodeInput.getText().toString().trim().toUpperCase();
        if (TextUtils.isEmpty(code)) {
            binding.referralCodeInput.setError("Please enter a code");
            return;
        }

        setLoading(true);

        Query query = mDatabase.child("users").orderByChild("referralCode").equalTo(code);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    DataSnapshot referrerSnapshot = dataSnapshot.getChildren().iterator().next();
                    String referrerId = referrerSnapshot.getKey();

                    if (referrerId.equals(currentUserId)) {
                        Toast.makeText(ApplyReferralActivity.this, "You cannot use your own code.", Toast.LENGTH_SHORT).show();
                        setLoading(false);
                        return;
                    }

                    // Code is valid, run transaction to apply bonuses
                    runReferralTransaction(referrerId, code);

                } else {
                    Toast.makeText(ApplyReferralActivity.this, "Invalid referral code.", Toast.LENGTH_SHORT).show();
                    setLoading(false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ApplyReferralActivity.this, "Database error. Please try again.", Toast.LENGTH_SHORT).show();
                setLoading(false);
            }
        });
    }

    private void runReferralTransaction(String referrerId, String code) {
        DatabaseReference referrerRef = mDatabase.child("users").child(referrerId);
        DatabaseReference newUserRef = mDatabase.child("users").child(currentUserId);
        
        // Fetch bonus amount from config
        mDatabase.child("app_config").child("rewards").child("referral_bonus").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) referralBonus = snapshot.getValue(Long.class);
                
                // Transaction for referrer: increment count and add coins
                referrerRef.runTransaction(new Transaction.Handler() {
                    @NonNull @Override
                    public Transaction.Result doTransaction(@NonNull MutableData mutableData) {
                        User user = mutableData.getValue(User.class);
                        if (user == null) return Transaction.success(mutableData);
                        user.referralCount++;
                        user.coins += referralBonus;
                        mutableData.setValue(user);
                        return Transaction.success(mutableData);
                    }
                    @Override public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot currentData) {}
                });

                // Transaction for new user: add coins and set referredBy
                newUserRef.runTransaction(new Transaction.Handler() {
                     @NonNull @Override
                     public Transaction.Result doTransaction(@NonNull MutableData mutableData) {
                        User user = mutableData.getValue(User.class);
                        if (user == null) return Transaction.success(mutableData);
                        user.coins += referralBonus; // Give bonus to new user as well
                        // user.referredBy = code; // Optional: store who referred them
                        mutableData.setValue(user);
                        return Transaction.success(mutableData);
                    }
                    @Override public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot currentData) {
                        if (committed) {
                            Toast.makeText(ApplyReferralActivity.this, "Success! You both received " + referralBonus + " coins!", Toast.LENGTH_LONG).show();
                            goToMain();
                        } else {
                            Toast.makeText(ApplyReferralActivity.this, "Failed to apply bonus. Please contact support.", Toast.LENGTH_SHORT).show();
                            setLoading(false);
                        }
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                setLoading(false);
            }
        });
    }

    private void goToMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
    
    private void setLoading(boolean isLoading) {
        binding.progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        binding.submitButton.setEnabled(!isLoading);
        binding.skipButton.setEnabled(!isLoading);
    }
}