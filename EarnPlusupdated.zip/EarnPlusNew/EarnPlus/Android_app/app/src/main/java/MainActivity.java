package com.earnplus.rewards.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.MobileAds;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.earnplus.rewards.R;
import com.earnplus.rewards.databinding.ActivityMainBinding;
import com.earnplus.rewards.fragments.HomeFragment;
import com.earnplus.rewards.fragments.OffersFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set the toolbar as the app's action bar for the options menu
        setSupportActionBar(binding.toolbar);

        // Initialize AdMob
        MobileAds.initialize(this, initializationStatus -> {});

        // Set Home as default fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
        }

        // Bottom Navigation
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                return true;
            } else if (itemId == R.id.nav_offers) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new OffersFragment()).commit();
                return true;
            } else if (itemId == R.id.nav_wallet) {
                startActivity(new Intent(this, WalletActivity.class));
                return false;
            } else if (itemId == R.id.nav_refer) {
    startActivity(new Intent(this, ReferActivity.class));
    return false;
}
            return false;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.menu_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        } else if (itemId == R.id.menu_refer) {
            startActivity(new Intent(this, ReferActivity.class));
            return true;
        } else if (itemId == R.id.menu_apply_referral) {
            startActivity(new Intent(this, ApplyReferralActivity.class));
            return true;
        } else if (itemId == R.id.menu_terms) {
            openInfoPage("terms", "Terms & Conditions");
            return true;
        } else if (itemId == R.id.menu_privacy) {
            openInfoPage("privacy", "Privacy Policy");
            return true;
        } else if (itemId == R.id.menu_faq) {
            openInfoPage("faq", "FAQ");
            return true;
        } else if (itemId == R.id.menu_contact) {
            openCustomLink("customer_service", "Contact link not set");
            return true;
        } else if (itemId == R.id.menu_telegram) {
            openCustomLink("telegram", "Telegram link not set");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openInfoPage(String pageType, String pageTitle) {
        Intent intent = new Intent(this, InfoActivity.class);
        intent.putExtra("PAGE_TYPE", pageType);
        intent.putExtra("PAGE_TITLE", pageTitle);
        startActivity(intent);
    }

    private void openCustomLink(String key, String failureMessage) {
        FirebaseDatabase.getInstance().getReference("app_config").child("links").child(key)
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists() && snapshot.getValue(String.class) != null && !snapshot.getValue(String.class).isEmpty()) {
                        String url = snapshot.getValue(String.class);
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Could not open link", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, failureMessage, Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(MainActivity.this, "Failed to load link", Toast.LENGTH_SHORT).show();
                }
            });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}