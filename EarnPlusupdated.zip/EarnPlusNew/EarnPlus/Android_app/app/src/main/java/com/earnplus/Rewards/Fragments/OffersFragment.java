package com.earnplus.rewards.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.earnplus.rewards.activities.WebViewActivity;
import com.earnplus.rewards.databinding.FragmentOffersBinding;

public class OffersFragment extends Fragment {

    private FragmentOffersBinding binding;
    private FirebaseUser currentUser;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentOffersBinding.inflate(inflater, container, false);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        setupOfferWallListeners();
    }

    private void setupOfferWallListeners() {
        // Example for CPAGrip
        binding.cardCpagrip.setOnClickListener(v -> {
            // In a real app, this URL should be fetched from Firebase/Admin Panel
            // It MUST include the user's unique ID to track completions.
            String cpaGripUrl = "https://www.cpagrip.com/show.php?l=0&u=" + currentUser.getUid() + "&key=YOUR_KEY";
            openOfferWall("CPAGrip Offers", cpaGripUrl);
        });

        // Example for Pollfish
        binding.cardPollfish.setOnClickListener(v -> {
            // Pollfish often has its own SDK, but can also be used via WebView
            String pollfishUrl = "https://www.pollfish.com/s/YOUR_API_KEY?user_id=" + currentUser.getUid();
            openOfferWall("Pollfish Surveys", pollfishUrl);
        });
        
        // Example for Offertoro
        binding.cardOffertoro.setOnClickListener(v -> {
            String offertoroUrl = "https://www.offertoro.com/ifr/YOUR_ID?pub_id=YOUR_PUB_ID&app_id=YOUR_APP_ID&user_id=" + currentUser.getUid();
            openOfferWall("Offertoro Tasks", offertoroUrl);
        });

        // Example for Timewall
        binding.cardTimewall.setOnClickListener(v -> {
            String timewallUrl = "https://timewall.io/users/login?api_key=YOUR_API_KEY&user_id=" + currentUser.getUid();
            openOfferWall("Timewall Offers", timewallUrl);
        });
    }

    private void openOfferWall(String title, String url) {
        if (currentUser == null) {
            Toast.makeText(getContext(), "You need to be logged in.", Toast.LENGTH_SHORT).show();
            return;
        }
        
        Intent intent = new Intent(getActivity(), WebViewActivity.class);
        intent.putExtra("title", title);
        intent.putExtra("url", url);
        startActivity(intent);
    }
    
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Avoid memory leaks
    }
}