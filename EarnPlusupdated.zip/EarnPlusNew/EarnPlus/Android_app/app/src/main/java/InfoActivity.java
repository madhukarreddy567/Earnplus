package com.earnplus.rewards.activities;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.earnplus.rewards.R;
import com.earnplus.rewards.databinding.ActivityInfoBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class InfoActivity extends AppCompatActivity {

    private ActivityInfoBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String pageType = getIntent().getStringExtra("PAGE_TYPE");
        String pageTitle = getIntent().getStringExtra("PAGE_TITLE");

        setTitle(pageTitle);
        binding.progressBar.setVisibility(View.VISIBLE);

        fetchContent(pageType);
    }

    private void fetchContent(String pageType) {
        OkHttpClient client = new OkHttpClient();
        String url = getString(R.string.admin_panel_api_url) + "get_page_content.php?page=" + pageType;

        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    binding.progressBar.setVisibility(View.GONE);
                    Toast.makeText(InfoActivity.this, "Failed to load content", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseBody = response.body().string();
                    runOnUiThread(() -> {
                        binding.progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject json = new JSONObject(responseBody);
                            if (json.getString("status").equals("success")) {
                                String content = json.getString("content");
                                binding.webView.loadDataWithBaseURL(null, content, "text/html", "UTF-8", null);
                            } else {
                                Toast.makeText(InfoActivity.this, json.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(InfoActivity.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}