package com.earnplus.rewards.models;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class User {
    public String uid, name, email, profilePhotoUrl, referralCode, deviceId;
    public long coins;
    public long referralCount; // New field
    public boolean isBlocked;

    public User() {
        // Default constructor required
    }

    public User(String uid, String name, String email, String profilePhotoUrl, long coins, long referralCount, String referralCode, String deviceId, boolean isBlocked) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.profilePhotoUrl = profilePhotoUrl;
        this.coins = coins;
        this.referralCount = referralCount;
        this.referralCode = referralCode;
        this.deviceId = deviceId;
        this.isBlocked = isBlocked;
    }
}