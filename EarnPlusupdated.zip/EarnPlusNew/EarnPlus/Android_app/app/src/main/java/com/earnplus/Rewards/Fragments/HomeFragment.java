package com.earnplus.rewards.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.earnplus.rewards.R;
import com.earnplus.rewards.activities.WebViewActivity; // Used for offer walls
import com.earnplus.rewards.databinding.FragmentHomeBinding;
import com.earnplus.rewards.models.User;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HomeFragment extends Fragment {

    // ViewBinding is the modern way to access views, replacing findViewById
    private FragmentHomeBinding binding;

    private FirebaseAuth mAuth;
    private DatabaseReference userRef;
    private DatabaseReference appConfigRef;

    // To prevent multiple clicks
    private boolean isCheckInProcessing = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment using ViewBinding
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // Get references to the specific nodes in Firebase
            userRef = FirebaseDatabase.getInstance().getReference("users").child(currentUser.getUid());
            appConfigRef = FirebaseDatabase.getInstance().getReference("app_config").child("rewards");
            
            // Start listening for user data changes (name, coins, etc.)
            loadUserData();
        }

        // Load the banner ad
        loadBannerAd();
        
        // Set up click listeners for all the earning cards
        setupClickListeners();
    }

    private void loadUserData() {
        // addValueEventListener keeps listening for realtime changes
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists() && getContext() != null) {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        // Update the UI with user data
                        binding.textUserName.setText(user.name);
                        binding.textCoinBalance.setText(String.valueOf(user.coins));

                        // Load profile image using Glide library
                        Glide.with(getContext())
                             .load(user.profilePhotoUrl)
                             .placeholder(R.drawable.ic_profile_placeholder) // Show placeholder while loading
                             .into(binding.imageProfile);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle potential errors, e.g., permission denied
                Toast.makeText(getContext(), "Failed to load user data.", Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    private void setupClickListeners() {
        // Daily Check-In
        binding.cardDailyCheckin.setOnClickListener(v -> handleDailyCheckIn());

        // Spin Wheel
        binding.cardSpinWheel.setOnClickListener(v -> showFeatureUnavailableToast());

        // Scratch Card
        binding.cardScratchCard.setOnClickListener(v -> showFeatureUnavailableToast());
        
        // Watch Ads
        binding.cardWatchAds.setOnClickListener(v -> showFeatureUnavailableToast());
        
        // KYC Offers
        binding.cardKycOffers.setOnClickListener(v -> {
            // Example of opening an offerwall in a WebView
            Intent intent = new Intent(getActivity(), WebViewActivity.class);
            intent.putExtra("url", "https://www.cpagrip.com/..."); // This URL should come from your admin panel
            intent.putExtra("title", "KYC Offers");
            startActivity(intent);
        });
        
        // App Tasks
        binding.cardAppTasks.setOnClickListener(v -> {
            // Another example for an offerwall
             Intent intent = new Intent(getActivity(), WebViewActivity.class);
            intent.putExtra("url", "https://www.offertoro.com/..."); // This URL should come from your admin panel
            intent.putExtra("title", "App Tasks");
            startActivity(intent);
        });
    }

    private void handleDailyCheckIn() {
        if (isCheckInProcessing) {
            return; // Don't do anything if a check-in is already in progress
        }
        isCheckInProcessing = true;
        
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // Use addListenerForSingleValueEvent to read data just once
        userRef.child("lastCheckIn").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String lastCheckInDate = snapshot.getValue(String.class);

                if (lastCheckInDate != null && lastCheckInDate.equals(todayDate)) {
                    Toast.makeText(getContext(), "You have already checked in today.", Toast.LENGTH_SHORT).show();
                    isCheckInProcessing = false;
                } else {
                    // User is eligible, now get the bonus amount from app_config
                    appConfigRef.child("daily_login_bonus").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot bonusSnapshot) {
                            long bonusAmount = bonusSnapshot.exists() ? bonusSnapshot.getValue(Long.class) : 10; // Default 10 coins

                            // Add coins and update the check-in date
                            addCoins(bonusAmount);
                            userRef.child("lastCheckIn").setValue(todayDate);
                            
                            Toast.makeText(getContext(), "You earned " + bonusAmount + " coins!", Toast.LENGTH_SHORT).show();
                            isCheckInProcessing = false;
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(getContext(), "Could not fetch bonus amount.", Toast.LENGTH_SHORT).show();
                            isCheckInProcessing = false;
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Failed to check daily login status.", Toast.LENGTH_SHORT).show();
                isCheckInProcessing = false;
            }
        });
    }
    
    private void addCoins(long amount) {
        // To safely add coins, we read the current value and add to it.
        userRef.child("coins").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                long currentCoins = snapshot.exists() ? snapshot.getValue(Long.class) : 0;
                long newTotal = currentCoins + amount;
                userRef.child("coins").setValue(newTotal);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error
            }
        });
    }

    private void loadBannerAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        binding.adView.loadAd(adRequest);
    }

    // Placeholder for features that are not yet fully implemented
    private void showFeatureUnavailableToast() {
        Toast.makeText(getContext(), "This feature is coming soon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Set binding to null to avoid memory leaks
        binding = null;
    }
}